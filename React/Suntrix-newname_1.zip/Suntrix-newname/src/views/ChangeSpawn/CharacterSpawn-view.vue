<template>
    <div id='SCS-view'>
        <router-view></router-view>

    </div>
</template>

<script>
    export default {
        name: 'CS-view',
        data() {
            return {
                
            }
        },
    }
</script>

<style lang="less" scoped>
@import '../../assets/SelectCharacter/style.less';
</style>